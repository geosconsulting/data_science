# Data Science Essentials
![Data Science Essentials](https://webview.edx.org/sites/default/files/styles/course_video_banner/public/course/image/featured-card/dat203x-course_image-378x225.png)
These files contain the lab steps and slides from the Microsoft Data Science Essentials course. To attend the full course, sign up for free on [edX](https://www.edx.org/course/data-science-essentials-microsoft-dat203-1x) .

